a:int=6

def fn(a:int,b:bool)->int:
    return a

# class ant:
#     x: int
#     y: list[float]
    
#     def add(x: int):
#         return x+1
fn(1,True)

# function call me 3ac me dikkat


# x: list[int] = [1,2,3,4,5]

