x: list[string]=["2","3","hc","enfek","hii"]
# print(x,x[2]*x[0],x[2],x[2]*x[3])

x[0] = "fw"
# ye to pura glt chl rha h

if 1 and 1:
    print("True")
    
# 3ac shi se nhi bn rha iska