def sum(x:int , y:int)->int:
    z:int = x + y
    return z

print(sum(1,2) , 10)

#   isme print 3ac me shi se kaam nhi kr rha